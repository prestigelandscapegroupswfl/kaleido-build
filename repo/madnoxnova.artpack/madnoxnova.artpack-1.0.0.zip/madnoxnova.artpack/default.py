import xbmc
xbmc.log('Madnox Nova Art Pack: data-only add-on, nothing to run.', xbmc.LOGINFO)
